import { useEffect, useRef, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { Route, Switch, Link, useLocation, Router as WouterRouter } from 'wouter';
import { Armchair, ArrowLeft, ArrowRight, Check, Grip, LockKeyhole, Plus, RefreshCw, Trash2, Users, X, BookOpen, ChevronRight, LayoutGrid } from 'lucide-react';

type Level = 'low' | 'medium' | 'high';
type Layout = 'pairs' | 'groups';
type Strength = 'hard' | 'soft';
type Student = { id: string; name: string; visibility: Level; behavior: Level };
type SeparationRule = { id: string; studentAId: string; studentBId: string; strength: Strength };
type Desk = { id: string; studentIds: string[]; x: number; y: number; manual?: boolean };
type Arrangement = { id: string; name: string; score: number; visibilityScore: number; behaviorScore: number; hardConflicts: number; softConflicts: number; desks: Desk[] };
type PlannerState = { className: string; layout: Layout; students: Student[]; rules: SeparationRule[]; candidates: Arrangement[]; selectedId: string | null; lockedIds: string[] };

const STORE_KEY = 'desk-planner-classroom-v1';
const CLASSES_KEY = 'desk-planner-classes-v2';
const demoNames = ['Ava', 'Ben', 'Carla', 'Diego', 'Elena', 'Finn', 'Grace', 'Hassan', 'Ivy', 'Jake', 'Kayla', 'Leo', 'Maya', 'Noah', 'Olivia', 'Priya', 'Quinn', 'Riley', 'Sofia', 'Theo', 'Uma', 'Victor', 'Willow', 'Zane'];
const levels: Level[] = ['low', 'medium', 'high'];
const levelValue = (v: Level) => levels.indexOf(v);
const makeId = () => typeof crypto !== 'undefined' && 'randomUUID' in crypto ? crypto.randomUUID() : `${Date.now()}-${Math.random().toString(36).slice(2)}`;

function groupSizes(n: number) {
  if (!n) return [];
  const count = Math.max(1, Math.round(n / 5));
  const base = Math.floor(n / count);
  const remainder = n % count;
  const sizes = Array(count).fill(base) as number[];
  for (let i = 0; i < remainder; i++) sizes[i]++;
  return sizes;
}

function makeDemo(): PlannerState {
  const students = demoNames.map((name, i): Student => ({
    id: `demo-${i + 1}`, name,
    visibility: (['medium', 'high', 'medium', 'low', 'medium', 'high'][i % 6]) as Level,
    behavior: (['low', 'medium', 'high', 'medium', 'low', 'medium'][i % 6]) as Level,
  }));
  const rules: SeparationRule[] = [
    { id: 'rule-demo-1', studentAId: students[1].id, studentBId: students[8].id, strength: 'hard' },
    { id: 'rule-demo-2', studentAId: students[4].id, studentBId: students[10].id, strength: 'soft' },
    { id: 'rule-demo-3', studentAId: students[7].id, studentBId: students[16].id, strength: 'hard' },
  ];
  const base: PlannerState = { className: 'Period 3 — Algebra II', layout: 'pairs', students, rules, candidates: [], selectedId: null, lockedIds: [] };
  const candidates = generateCandidates(base);
  return { ...base, candidates, selectedId: candidates[0]?.id ?? null };
}

function readLegacySaved(): PlannerState | null {
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as PlannerState;
    if (!Array.isArray(parsed.students) || !Array.isArray(parsed.rules)) return null;
    return { ...makeDemo(), ...parsed, layout: parsed.layout === 'groups' ? 'groups' : 'pairs', candidates: Array.isArray(parsed.candidates) ? parsed.candidates : [], lockedIds: Array.isArray(parsed.lockedIds) ? parsed.lockedIds : [] };
  } catch { return null; }
}
type ClassRecord = { id: string; state: PlannerState; createdAt: number };
function emptyClass(): PlannerState { return { className: '', layout: 'pairs', students: [], rules: [], candidates: [], selectedId: null, lockedIds: [] }; }
function readClasses(): ClassRecord[] {
  try {
    const raw = localStorage.getItem(CLASSES_KEY);
    if (raw) {
      const list = JSON.parse(raw) as ClassRecord[];
      if (Array.isArray(list)) return list.filter(item => item?.id && item?.state);
    }
    const legacy = readLegacySaved();
    if (legacy) {
      const migrated = [{ id: 'migrated-classroom', state: legacy, createdAt: Date.now() }];
      localStorage.setItem(CLASSES_KEY, JSON.stringify(migrated));
      return migrated;
    }
  } catch { /* keep this device usable even when storage is unavailable */ }
  return [];
}

function capacities(layout: Layout, count: number) {
  return layout === 'pairs' ? Array(Math.ceil(count / 2)).fill(2) as number[] : groupSizes(count);
}

function roomGeometry(layout: Layout, count: number, viewportWidth: number) {
  const maxColumns = viewportWidth <= 640 ? (layout === 'groups' ? 1 : 2) : viewportWidth <= 1100 ? 3 : 4;
  const roomWidth = Math.max(300, viewportWidth - (viewportWidth <= 640 ? 54 : 150));
  const deskWidth = layout === 'groups' ? (viewportWidth <= 640 ? Math.min(272, viewportWidth - 70) : 300) : (viewportWidth <= 640 ? Math.min(236, viewportWidth - 70) : 250);
  const sideMargin = viewportWidth <= 640 ? 18 : 32;
  const horizontalGap = viewportWidth <= 640 ? 28 : 56;
  const verticalMargin = viewportWidth <= 640 ? 28 : 40;
  const verticalGap = viewportWidth <= 640 ? 36 : 56;
  const fitColumns = Math.max(1, Math.floor((roomWidth - 2 * sideMargin + horizontalGap) / (deskWidth + horizontalGap)));
  const cols = Math.max(1, Math.min(count, maxColumns, fitColumns, Math.ceil(Math.sqrt(count))));
  const rows = Math.ceil(count / cols);
  const deskHeight = layout === 'pairs' ? 165 : 255;
  const roomHeight = Math.max(viewportWidth <= 640 ? 680 : 550, rows * deskHeight + Math.max(0, rows - 1) * verticalGap + 2 * verticalMargin);
  return {
    cols,
    rows,
    roomHeight,
    startX: (sideMargin / roomWidth) * 100,
    centerX: ((roomWidth - deskWidth) / 2 / roomWidth) * 100,
    maxX: 100 - ((deskWidth + sideMargin) / roomWidth) * 100,
    startY: (verticalMargin / roomHeight) * 100,
    centerY: ((roomHeight - deskHeight) / 2 / roomHeight) * 100,
    maxY: 100 - ((deskHeight + verticalMargin) / roomHeight) * 100,
  };
}

function makeDeskPositions(layout: Layout, count: number, viewportWidth: number) {
  const geometry = roomGeometry(layout, count, viewportWidth);
  const { cols, rows, startX, centerX, maxX, startY, centerY, maxY } = geometry;
  return Array.from({ length: count }, (_, i) => ({
    x: cols === 1 ? centerX : startX + (i % cols) * ((maxX - startX) / Math.max(cols - 1, 1)),
    y: rows === 1 ? centerY : startY + Math.floor(i / cols) * ((maxY - startY) / Math.max(rows - 1, 1)),
  }));
}

function conflictsFor(desks: Desk[], rules: SeparationRule[]) {
  const deskOf = new Map<string, string>();
  desks.forEach(desk => desk.studentIds.forEach(id => deskOf.set(id, desk.id)));
  let hard = 0; let soft = 0;
  rules.forEach(rule => {
    if (deskOf.has(rule.studentAId) && deskOf.get(rule.studentAId) === deskOf.get(rule.studentBId)) {
      if (rule.strength === 'hard') hard++; else soft++;
    }
  });
  return { hard, soft };
}

function scoreDesks(desks: Desk[], students: Student[], rules: SeparationRule[]) {
  const assigned = new Set(desks.flatMap(desk => desk.studentIds));
  const seated = students.filter(student => assigned.has(student.id));
  if (!seated.length) return { score: 0, visibilityScore: 0, behaviorScore: 0, hardConflicts: 0, softConflicts: 0 };
  const visibilityScore = Math.round(seated.reduce((sum, student) => {
    const y = desks.find(desk => desk.studentIds.includes(student.id))?.y ?? 50;
    const ideal = student.visibility === 'high' ? 15 : student.visibility === 'medium' ? 42 : 72;
    return sum + Math.max(0, 100 - Math.abs(y - ideal) * 1.35);
  }, 0) / seated.length);
  const highCounts = desks.map(desk => desk.studentIds.reduce((sum, id) => sum + (students.find(student => student.id === id)?.behavior === 'high' ? 1 : 0), 0));
  const mean = highCounts.reduce((a, b) => a + b, 0) / Math.max(highCounts.length, 1);
  const spread = Math.sqrt(highCounts.reduce((sum, value) => sum + (value - mean) ** 2, 0) / Math.max(highCounts.length, 1));
  const behaviorScore = Math.max(0, Math.round(100 - spread * 30));
  const { hard, soft } = conflictsFor(desks, rules);
  const coverage = seated.length / Math.max(students.length, 1);
  const score = Math.max(0, Math.min(100, Math.round((visibilityScore * .45 + behaviorScore * .3 + 25 - hard * 16 - soft * 6) * coverage)));
  return { score, visibilityScore, behaviorScore, hardConflicts: hard, softConflicts: soft };
}

function randomValue(seed: number) {
  const value = Math.sin(seed * 999.91) * 10000;
  return value - Math.floor(value);
}

function createArrangement(base: PlannerState, variant: number): Arrangement {
  const slots = capacities(base.layout, base.students.length);
  const current = base.candidates.find(candidate => candidate.id === base.selectedId);
  const fallbackPositions = makeDeskPositions(base.layout, slots.length, typeof window === 'undefined' ? 1280 : window.innerWidth);
  const positions = fallbackPositions.map((position, index) => current?.desks[index]?.manual
    ? { x: current.desks[index].x, y: current.desks[index].y }
    : position);
  const deskSlots: Array<Array<string | null>> = slots.map(size => Array(size).fill(null));
  const lockPlaced = new Set<string>();
  if (current) {
    current.desks.forEach((desk, di) => desk.studentIds.forEach((id, si) => {
      if (!base.lockedIds.includes(id) || di >= deskSlots.length || si >= deskSlots[di].length || lockPlaced.has(id)) return;
      if (!deskSlots[di][si]) { deskSlots[di][si] = id; lockPlaced.add(id); }
    }));
  }
  const remaining = base.students.filter(student => !lockPlaced.has(student.id)).sort((a, b) => {
    const delta = levelValue(b.visibility) - levelValue(a.visibility);
    return delta || (randomValue(variant * 113 + base.students.indexOf(a) * 71) - randomValue(variant * 113 + base.students.indexOf(b) * 71));
  });
  const placed = new Set(lockPlaced);
  for (const student of remaining) {
    const choices: Array<{ di: number; si: number; cost: number }> = [];
    deskSlots.forEach((slotsAtDesk, di) => slotsAtDesk.forEach((slot, si) => {
      if (slot !== null) return;
      const ids = deskSlots[di].filter((id): id is string => id !== null);
      const hard = base.rules.filter(rule => rule.strength === 'hard' && ((rule.studentAId === student.id && ids.includes(rule.studentBId)) || (rule.studentBId === student.id && ids.includes(rule.studentAId)))).length;
      const soft = base.rules.filter(rule => rule.strength === 'soft' && ((rule.studentAId === student.id && ids.includes(rule.studentBId)) || (rule.studentBId === student.id && ids.includes(rule.studentAId)))).length;
      const highCount = ids.reduce((sum, id) => sum + (base.students.find(item => item.id === id)?.behavior === 'high' ? 1 : 0), 0);
      const behaviorCost = student.behavior === 'high' ? highCount * 18 : highCount * 5;
      const y = positions[di]?.y ?? 50;
      const ideal = student.visibility === 'high' ? 15 : student.visibility === 'medium' ? 42 : 72;
      const visibilityCost = Math.abs(y - ideal) * .18;
      const noise = randomValue(variant * 107 + base.students.indexOf(student) * 17 + di * 29 + si) * (2 + variant * .8);
      choices.push({ di, si, cost: hard * 10000 + soft * 42 + behaviorCost + visibilityCost + noise });
    }));
    choices.sort((a, b) => a.cost - b.cost);
    const chosen = choices[0];
    if (chosen) { deskSlots[chosen.di][chosen.si] = student.id; placed.add(student.id); }
  }
  const desks: Desk[] = deskSlots.map((studentIds, i) => ({
    id: `desk-${variant}-${i + 1}`,
    studentIds: studentIds.filter((id): id is string => id !== null),
    x: positions[i]?.x ?? 10,
    y: positions[i]?.y ?? 10,
    manual: current?.desks[i]?.manual ?? false,
  }));
  const metrics = scoreDesks(desks, base.students, base.rules);
  return { id: makeId(), name: `Option ${String.fromCharCode(65 + variant)}`, desks, ...metrics };
}

function generateCandidates(base: PlannerState) {
  if (!base.students.length) return [];
  const candidates = Array.from({ length: 5 }, (_, i) => createArrangement(base, i + 1));
  return candidates.sort((a, b) => b.score - a.score);
}

function AppFrame({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  return (
    <div className="app-shell">
      <header className="topbar">
        <Link href="/" className="brand-lockup" data-testid="link-brand-home">
          <span className="brand-mark">d.</span>
          <span><span className="brand-name">Desk planner</span><span className="brand-caption">A thoughtful seat for everyone</span></span>
        </Link>
        <nav className="top-nav" aria-label="Main navigation">
          <Link href="/" className={`nav-link ${location === '/' ? 'active' : ''}`} data-testid="link-tools-home"><LayoutGrid size={15} /> Tools</Link>
          <Link href="/classes" className={`nav-link ${location.startsWith('/classes') ? 'active' : ''}`} data-testid="link-classes"><Users size={15} /> My classes</Link>
        </nav>
        <div className="top-status"><span className="status-dot" /> Saved on this device</div>
      </header>
      {children}
    </div>
  );
}

function Home() {
  return <main className="page hub-page" data-testid="page-home">
    <div className="hub-intro"><div><div className="eyebrow">A little more room to think</div><h1 className="page-title">Tools for the classroom,<br />starting with the seats.</h1><p className="page-subtitle">Plan a room that works for the students in front of you. No student accounts, no setup overhead — just your class and a thoughtful starting point.</p></div><div className="hub-note"><BookOpen size={18}/><span>Made for teachers<br/><small>Saved on this device</small></span></div></div>
    <section className="tool-card feature-tool" data-testid="card-tool-desk-planner">
      <div className="tool-illustration"><div className="mini-board">FRONT OF ROOM</div><div className="mini-table"><i/><i/></div><div className="mini-table second"><i/><i/></div><span>01</span></div>
      <div className="tool-copy"><div className="tool-kicker">CLASSROOM TOOL · READY TO USE</div><h2>Desk Planner</h2><p>Build your roster, note the needs that matter, then explore five seating possibilities for each class.</p><Link href="/classes" className="button primary" data-testid="link-open-desk-planner">Open Desk Planner <ArrowRight size={15}/></Link></div>
      <div className="tool-index">01 / 02</div>
    </section>
    <section className="tool-card coming-tool" data-testid="card-tool-group-maker"><div className="coming-mark"><Users size={24}/><span>02</span></div><div><div className="tool-kicker">COMING SOON</div><h2>Group Maker</h2><p>A future tool for putting students into working groups.</p></div><span className="coming-pill">In the works</span></section>
    <p className="local-note">Your classes and room plans stay in this browser on this device.</p>
  </main>;
}

function ClassesPage({ classes, createClass }: { classes: ClassRecord[]; createClass: () => void }) {
  return <main className="page" data-testid="page-classes">
    <div className="page-heading"><div><div className="eyebrow">Desk Planner / Your workspace</div><h1 className="page-title">Choose a class to arrange.</h1><p className="page-subtitle">Each class has its own roster, seating preferences and room plan.</p></div><button className="button primary" onClick={createClass} data-testid="button-create-class"><Plus size={15}/> New class</button></div>
    {classes.length === 0 ? <section className="empty-classes" data-testid="empty-classes"><div className="empty-icon"><Users size={25}/></div><div className="eyebrow">A fresh start</div><h2>Your class list is empty.</h2><p>Create a class, add your students when you’re ready, and build a room plan from there.</p><button className="button primary" onClick={createClass} data-testid="button-create-first-class"><Plus size={15}/> Create your first class</button></section> :
      <div className="class-list" data-testid="list-classes">{classes.map((item, index) => <article className="class-card" key={item.id} data-testid={`card-class-${item.id}`}><div className="class-card-number">{String(index + 1).padStart(2, '0')}</div><div className="class-card-main"><div className="eyebrow">{item.state.layout === 'pairs' ? 'PAIRS' : 'GROUPS'} · {item.state.students.length} STUDENTS</div><h2>{item.state.className.trim() || 'Untitled class'}</h2><p>{item.state.rules.length ? `${item.state.rules.length} seating ${item.state.rules.length === 1 ? 'rule' : 'rules'} saved` : 'Ready for your class details'}</p></div><div className="class-actions"><Link href={`/classes/${item.id}/setup`} className="button" data-testid={`link-edit-class-${item.id}`}>Edit setup</Link><Link href={`/classes/${item.id}/planner`} className="button primary" data-testid={`link-plan-class-${item.id}`}>Arrange room <ChevronRight size={15}/></Link></div></article>)}</div>}
  </main>;
}

function Classroom({ state, update, classId }: { state: PlannerState; update: (next: PlannerState) => void; classId: string }) {
  const roomRef = useRef<HTMLDivElement>(null);
  const [viewportWidth, setViewportWidth] = useState(() => typeof window === 'undefined' ? 1280 : window.innerWidth);
  const drag = useRef<{ pointerId: number; deskId: string; offsetX: number; offsetY: number } | null>(null);
  const chosen = state.candidates.find(candidate => candidate.id === state.selectedId);
  const deskCount = chosen?.desks.length ?? capacities(state.layout, state.students.length).length;
  const geometry = roomGeometry(state.layout, deskCount, viewportWidth);
  const responsivePositions = makeDeskPositions(state.layout, deskCount, viewportWidth);
  const metric = chosen ? scoreDesks(chosen.desks, state.students, state.rules) : null;
  const assigned = new Set(chosen?.desks.flatMap(desk => desk.studentIds) ?? []);
  const notSeated = state.students.filter(student => !assigned.has(student.id));

  useEffect(() => {
    const handleResize = () => setViewportWidth(window.innerWidth);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const choose = (id: string) => update({ ...state, selectedId: id });
  const generate = () => {
    const candidates = generateCandidates(state);
    update({ ...state, candidates, selectedId: candidates[0]?.id ?? null });
  };
  const toggleLock = (studentId: string) => update({ ...state, lockedIds: state.lockedIds.includes(studentId) ? state.lockedIds.filter(id => id !== studentId) : [...state.lockedIds, studentId] });
  const onPointerDown = (event: React.PointerEvent<HTMLDivElement>, desk: Desk) => {
    if (!roomRef.current) return;
    const bounds = event.currentTarget.getBoundingClientRect();
    drag.current = { pointerId: event.pointerId, deskId: desk.id, offsetX: event.clientX - bounds.left, offsetY: event.clientY - bounds.top };
    event.currentTarget.setPointerCapture(event.pointerId);
  };
  const onPointerMove = (event: React.PointerEvent<HTMLDivElement>) => {
    if (!drag.current || drag.current.pointerId !== event.pointerId || !roomRef.current || !chosen) return;
    const room = roomRef.current.getBoundingClientRect();
    const deskNode = roomRef.current.querySelector(`[data-desk="${drag.current.deskId}"]`) as HTMLElement | null;
    const width = deskNode?.offsetWidth ?? 165; const height = deskNode?.offsetHeight ?? 110;
    const px = Math.max(0, Math.min(room.width - width - 10, room.width * geometry.maxX / 100, event.clientX - room.left - drag.current.offsetX));
    const py = Math.max(0, Math.min(room.height - height - 10, room.height * geometry.maxY / 100, event.clientY - room.top - drag.current.offsetY));
    const desks = chosen.desks.map(desk => desk.id === drag.current?.deskId ? { ...desk, x: px / room.width * 100, y: py / room.height * 100, manual: true } : desk);
    const candidates = state.candidates.map(candidate => candidate.id === chosen.id ? { ...candidate, desks, ...scoreDesks(desks, state.students, state.rules) } : candidate);
    update({ ...state, candidates });
  };
  const onPointerUp = (event: React.PointerEvent<HTMLDivElement>) => {
    if (drag.current?.pointerId === event.pointerId) drag.current = null;
  };
  const onKeyPosition = (event: React.KeyboardEvent<HTMLDivElement>, desk: Desk) => {
    if (!chosen || !['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(event.key)) return;
    event.preventDefault();
    const step = event.shiftKey ? 5 : 2;
    const visualPosition = desk.manual ? desk : (responsivePositions[chosen.desks.findIndex(item => item.id === desk.id)] ?? desk);
    const x = Math.max(0, Math.min(geometry.maxX, visualPosition.x + (event.key === 'ArrowLeft' ? -step : event.key === 'ArrowRight' ? step : 0)));
    const y = Math.max(0, Math.min(geometry.maxY, visualPosition.y + (event.key === 'ArrowUp' ? -step : event.key === 'ArrowDown' ? step : 0)));
    const desks = chosen.desks.map(item => item.id === desk.id ? { ...item, x, y, manual: true } : item);
    update({ ...state, candidates: state.candidates.map(candidate => candidate.id === chosen.id ? { ...candidate, desks, ...scoreDesks(desks, state.students, state.rules) } : candidate) });
  };
  const hardRemaining = metric?.hardConflicts ?? 0;
  const softRemaining = metric?.softConflicts ?? 0;

  return <main className="page" data-testid="page-classroom">
    <div className="page-heading">
      <div><div className="eyebrow">The room, at a glance</div><h1 className="page-title">Make space for a better day.</h1><p className="page-subtitle">Compare thoughtful starting points, then move desks until the room feels right. You make the final call.</p></div>
      <button className="button primary" onClick={generate} data-testid="button-generate"><RefreshCw size={15} /> Generate arrangements</button>
    </div>
    <div className="map-toolbar">
      <div className="map-toolbar-left"><div className="class-name-display" data-testid="text-class-name">{state.className.trim() || 'Untitled class'}</div><span className="class-meta" data-testid="text-student-count">{state.students.length} students</span><span className="layout-chip">{state.layout === 'pairs' ? 'Pairs of 2' : 'Groups of 5'}</span></div>
      <Link href={`/classes/${classId}/setup`} className="button small" data-testid="link-edit-class"><span>Edit class</span><ArrowRight size={13} /></Link>
    </div>
    <section className="classroom-panel" aria-label="Classroom map">
      <div className="board">WHITEBOARD · FRONT OF ROOM</div>
      <div ref={roomRef} className="room" style={{ height: `${geometry.roomHeight}px` }} onPointerMove={onPointerMove} onPointerUp={onPointerUp} onPointerCancel={onPointerUp} data-testid="classroom-room">
        {chosen?.desks.map((desk, index) => <div
          key={desk.id}
          className={`desk ${state.layout === 'groups' ? 'group-desk' : 'pair-desk'} ${drag.current?.deskId === desk.id ? 'dragging' : ''}`}
          data-desk={desk.id}
          data-testid={`desk-unit-${index + 1}`}
          style={{
            left: `${Math.min(desk.manual ? desk.x : responsivePositions[index]?.x ?? desk.x, geometry.maxX)}%`,
            top: `${Math.min(desk.manual ? desk.y : responsivePositions[index]?.y ?? desk.y, geometry.maxY)}%`,
          }}
          onPointerDown={event => onPointerDown(event, desk)}
          onKeyDown={event => onKeyPosition(event, desk)}
          tabIndex={0}
          aria-label={`Move ${state.layout === 'pairs' ? 'Desk' : 'Group'} ${index + 1}; use arrow keys to reposition`}
        >
          <div className="desk-label"><span>{state.layout === 'pairs' ? `DESK ${String(index + 1).padStart(2, '0')}` : `GROUP ${String(index + 1).padStart(2, '0')}`}</span><span style={{ display: 'flex', alignItems: 'center', gap: 7 }}><Grip size={12} /><button className={`desk-lock ${desk.studentIds.some(id => state.lockedIds.includes(id)) ? 'locked' : ''}`} onPointerDown={event => event.stopPropagation()} onClick={event => { event.stopPropagation(); const lockAll = !desk.studentIds.every(id => state.lockedIds.includes(id)); const lockedIds = lockAll ? Array.from(new Set([...state.lockedIds, ...desk.studentIds])) : state.lockedIds.filter(id => !desk.studentIds.includes(id)); update({ ...state, lockedIds }); }} title="Lock or unlock the students at this desk" data-testid={`button-lock-desk-${index + 1}`}><LockKeyhole size={11} />{desk.studentIds.some(id => state.lockedIds.includes(id)) ? 'LOCKED' : 'LOCK'}</button></span></div>
           <div className="tabletop" aria-hidden="true"><span>{state.layout === 'pairs' ? 'SHARED TABLE' : 'TEAM TABLE'}</span></div>
           <div className={`desk-seats seats-${desk.studentIds.length}`}>{desk.studentIds.map((id, seatIndex) => {
            const student = state.students.find(person => person.id === id);
            if (!student) return null;
             return <div className={`seat seat-around seat-index-${seatIndex}`} key={id} data-testid={`seat-student-${id}`}><span className="seat-name">{student.name.trim() || 'Unnamed student'}</span><span className="seat-tags">{state.lockedIds.includes(id) && <span className="trait-tag locked-tag">FIXED</span>}<span className="trait-tag" title={`Visibility ${student.visibility}`}>V{student.visibility[0].toUpperCase()}</span><button className={`desk-lock ${state.lockedIds.includes(id) ? 'locked' : ''}`} onPointerDown={event => event.stopPropagation()} onClick={event => { event.stopPropagation(); toggleLock(id); }} title={state.lockedIds.includes(id) ? 'Unlock this student’s seat' : 'Keep this student in this exact seat on the next generation'} aria-label={state.lockedIds.includes(id) ? `Unlock ${student.name}` : `Lock ${student.name} in this seat`} data-testid={`button-lock-student-${id}`}><LockKeyhole size={10} /></button></span></div>;
          })}</div>
        </div>)}
        {!chosen && <div className="room-empty"><div><strong>Your classroom is ready</strong>Generate a few arrangements to start exploring the room.</div></div>}
        {notSeated.length > 0 && chosen && <div className="room-hint" data-testid="status-students-unseated">{notSeated.length} student{notSeated.length === 1 ? '' : 's'} need a seat · generate again</div>}
        <div className="room-hint" style={{ left: 14, right: 'auto' }}>Drag desks to arrange · changes save automatically</div>
      </div>
    </section>
    <div className="compare-grid">
      <section className="panel">
        <div className="panel-head"><div><div className="eyebrow">Compare options</div><h2 className="panel-title">Generated arrangements</h2><p className="panel-description">Choose one to review it in the room. Generate again for fresh alternatives.</p></div><span className="count-badge" data-testid="text-candidate-count">{state.candidates.length} OPTIONS</span></div>
        {state.candidates.length === 0 ? <div className="rule-empty">No arrangements yet. Generate options when your roster is ready.</div> : <div className="candidate-list">{state.candidates.map(candidate => {
          const metrics = scoreDesks(candidate.desks, state.students, state.rules);
          return <button key={candidate.id} className={`candidate ${candidate.id === state.selectedId ? 'selected' : ''}`} onClick={() => choose(candidate.id)} data-testid={`button-select-${candidate.name.toLowerCase().replace(' ', '-')}`} aria-pressed={candidate.id === state.selectedId}>
            <span className="candidate-score">{metrics.score}</span><span className="candidate-copy"><span className="candidate-name">{candidate.name}</span><span className="candidate-detail">Visibility {metrics.visibilityScore} · Balance {metrics.behaviorScore}<br />{metrics.hardConflicts} hard · {metrics.softConflicts} soft conflicts</span></span><span className={`candidate-flag ${metrics.hardConflicts === 0 ? 'clean' : ''}`}>{metrics.hardConflicts === 0 ? 'No hard conflicts' : 'Review'}</span>
          </button>;
        })}</div>}
      </section>
      <section className="panel">
        <div className="panel-head"><div><div className="eyebrow">A useful starting point</div><h2 className="panel-title">Why this option?</h2></div><span className="count-badge">{chosen?.name ?? 'NOT SELECTED'}</span></div>
        {metric ? <><div className="insight-score" data-testid="text-arrangement-score">{metric.score}<small>/100</small></div><p className="insight-text">A comparison score, not a verdict. Visibility and balanced behavior needs shape the suggestion; separation rules are reported plainly.</p><div className="insight-stats"><div className="insight-stat"><strong data-testid="text-hard-conflicts">{hardRemaining}</strong><span>hard conflicts</span></div><div className="insight-stat"><strong data-testid="text-soft-conflicts">{softRemaining}</strong><span>soft conflicts</span></div><div className="insight-stat"><strong>{metric.visibilityScore}%</strong><span>visibility fit</span></div><div className="insight-stat"><strong>{metric.behaviorScore}%</strong><span>behavior balance</span></div></div></> : <p className="insight-text">Generate a set of alternatives to see what each one prioritizes.</p>}
        <div className="disclaimer"><Check size={14} /> {hardRemaining === 0 ? 'No hard separation conflicts in this option. Take a look and make the arrangement your own.' : `This option still has ${hardRemaining} hard conflict${hardRemaining === 1 ? '' : 's'}. The planner avoids them where possible, but cannot always satisfy every rule.`}</div>
      </section>
    </div>
  </main>;
}

function Setup({ state, update, classId }: { state: PlannerState; update: (next: PlannerState) => void; classId: string }) {
  const renameStudent = (id: string, name: string) => update({ ...state, students: state.students.map(student => student.id === id ? { ...student, name } : student) });
  const updateTrait = (id: string, key: 'visibility' | 'behavior', value: Level) => update({ ...state, students: state.students.map(student => student.id === id ? { ...student, [key]: value } : student) });
  const addStudent = () => update({ ...state, students: [...state.students, { id: makeId(), name: `Student ${state.students.length + 1}`, visibility: 'medium', behavior: 'medium' }] });
  const deleteStudent = (id: string) => {
    const students = state.students.filter(student => student.id !== id);
    const rules = state.rules.filter(rule => rule.studentAId !== id && rule.studentBId !== id);
    const candidates = state.candidates.map(candidate => {
      const desks = candidate.desks.map(desk => ({ ...desk, studentIds: desk.studentIds.filter(studentId => studentId !== id) }));
      return { ...candidate, desks, ...scoreDesks(desks, students, rules) };
    });
    update({ ...state, students, rules, candidates, lockedIds: state.lockedIds.filter(item => item !== id) });
  };
  const addRule = () => {
    if (state.students.length < 2) return;
    const pair = state.students.find((student, index) => !state.rules.some(rule => (rule.studentAId === student.id && rule.studentBId === state.students[(index + 1) % state.students.length]?.id) || (rule.studentBId === student.id && rule.studentAId === state.students[(index + 1) % state.students.length]?.id)));
    const first = pair ?? state.students[0];
    const second = state.students.find(student => student.id !== first.id);
    if (!second) return;
    update({ ...state, rules: [...state.rules, { id: makeId(), studentAId: first.id, studentBId: second.id, strength: 'hard' }] });
  };
  const updateRule = (id: string, patch: Partial<SeparationRule>) => update({ ...state, rules: state.rules.map(rule => rule.id === id ? { ...rule, ...patch } : rule) });
  const removeRule = (id: string) => update({ ...state, rules: state.rules.filter(rule => rule.id !== id) });
  const layoutChange = (layout: Layout) => update({ ...state, layout, candidates: [], selectedId: null });

  return <main className="page" data-testid="page-setup">
    <div className="page-heading"><div><div className="eyebrow">Build the picture</div><h1 className="page-title">A little context goes a long way.</h1><p className="page-subtitle">Set up the class and what matters to your students. Your classroom map stays on its own page, ready for your final judgement.</p></div><div className="save-note"><span className="save-dot" /> Saved automatically on this device</div></div>
    <div className="setup-grid">
      <div className="setup-stack">
        <section className="panel">
          <p className="section-kicker">01 / Class & format</p>
          <div className="setup-name-row"><div><label className="field-label" htmlFor="class-name">Class name</label><input id="class-name" className="text-field" value={state.className} onChange={event => update({ ...state, className: event.target.value })} placeholder="e.g. Period 3 — Algebra II" data-testid="input-class-name" /></div><span className="roster-count">{state.students.length} STUDENTS</span></div>
          <div style={{ marginTop: 19 }}><div className="field-label">How will desks be arranged?</div><div className="layout-options">
            <button className={`layout-option ${state.layout === 'pairs' ? 'active' : ''}`} onClick={() => layoutChange('pairs')} data-testid="button-layout-pairs"><span className="layout-option-icon"><Armchair size={17} /></span><span><strong>Pairs of two</strong><small>Shared desks, side by side</small></span></button>
            <button className={`layout-option ${state.layout === 'groups' ? 'active' : ''}`} onClick={() => layoutChange('groups')} data-testid="button-layout-groups"><span className="layout-option-icon"><Users size={17} /></span><span><strong>Groups around five</strong><small>Balanced groups; everyone seated</small></span></button>
          </div></div>
          {state.layout === 'groups' && <p className="rules-footnote" data-testid="text-group-sizing">Groups are balanced toward 4–6 students when possible. With {state.students.length} students: {groupSizes(state.students.length).join(' · ') || 'no groups yet'}.</p>}
        </section>
        <section className="panel">
          <div className="roster-header"><div><p className="section-kicker" style={{ marginBottom: 4 }}>02 / Student roster</p><span className="panel-description">Add names and use the simple scales to express what could help.</span></div><span className="roster-count">{state.students.length} TOTAL</span></div>
          {state.students.length > 0 && <div className="table-labels"><span>STUDENT</span><span>VISIBILITY</span><span>BEHAVIOR</span><span /></div>}
          <div className="student-table">{state.students.map(student => <div key={student.id} className="student-row" data-testid={`row-student-${student.id}`}>
            <input className="student-name" aria-label={`${student.name} name`} value={student.name} onChange={event => renameStudent(student.id, event.target.value)} data-testid={`input-student-name-${student.id}`} />
            <label><span className="sr-only">Visibility for {student.name}</span><select className="trait-select" value={student.visibility} onChange={event => updateTrait(student.id, 'visibility', event.target.value as Level)} data-testid={`select-visibility-${student.id}`}>{levels.map(level => <option key={level} value={level}>{level[0].toUpperCase() + level.slice(1)}</option>)}</select></label>
            <label><span className="sr-only">Behavior need for {student.name}</span><select className="trait-select" value={student.behavior} onChange={event => updateTrait(student.id, 'behavior', event.target.value as Level)} data-testid={`select-behavior-${student.id}`}>{levels.map(level => <option key={level} value={level}>{level[0].toUpperCase() + level.slice(1)}</option>)}</select></label>
            <button className="delete-icon" onClick={() => { if (window.confirm(`Remove ${student.name || 'this student'} from the class?`)) deleteStudent(student.id); }} aria-label={`Remove ${student.name}`} title="Remove student" data-testid={`button-delete-student-${student.id}`}><Trash2 size={14} /></button>
          </div>)}
          {state.students.length === 0 && <div className="rule-empty">Your roster is ready for its first name.</div>}
          </div>
          <button className="add-student" onClick={addStudent} data-testid="button-add-student"><Plus size={14} style={{ verticalAlign: 'middle', marginRight: 5 }} /> Add a student</button>
        </section>
      </div>
      <section className="panel">
        <div className="roster-header"><div><p className="section-kicker" style={{ marginBottom: 4 }}>03 / Separation rules</p><span className="panel-description">Good to know, not always possible. The score shows what remains.</span></div><button className="button small" onClick={addRule} disabled={state.students.length < 2} data-testid="button-add-rule"><Plus size={13} /> Add rule</button></div>
        {state.rules.length === 0 ? <div className="rule-empty"><div style={{ marginBottom: 7 }}><Users size={18} /></div>No separation rules yet. Add one when there’s a pairing you’d like the planner to consider.</div> : <div className="rule-list">{state.rules.map(rule => <div className="rule-row" key={rule.id} data-testid={`row-rule-${rule.id}`}>
          <label><span className="field-label">Student A</span><select className="select-field" value={rule.studentAId} onChange={event => event.target.value === rule.studentBId ? updateRule(rule.id, { studentAId: rule.studentBId, studentBId: rule.studentAId }) : updateRule(rule.id, { studentAId: event.target.value })} data-testid={`select-rule-a-${rule.id}`}>{state.students.map(student => <option key={student.id} value={student.id}>{student.name || 'Unnamed student'}</option>)}</select></label>
          <label><span className="field-label">Student B</span><select className="select-field" value={rule.studentBId} onChange={event => updateRule(rule.id, { studentBId: event.target.value })} data-testid={`select-rule-b-${rule.id}`}>{state.students.filter(student => student.id !== rule.studentAId).map(student => <option key={student.id} value={student.id}>{student.name || 'Unnamed student'}</option>)}</select></label>
          <label className="rule-strength"><span className="field-label">How important?</span><select className="select-field" value={rule.strength} onChange={event => updateRule(rule.id, { strength: event.target.value as Strength })} data-testid={`select-rule-strength-${rule.id}`}><option value="hard">Don’t sit together — hard rule</option><option value="soft">Try not to sit together — preference</option></select></label>
          <button className="delete-icon rule-remove" aria-label="Remove separation rule" onClick={() => removeRule(rule.id)} data-testid={`button-delete-rule-${rule.id}`}><X size={15} /></button>
        </div>)}</div>}
        <p className="rules-footnote">Hard rules are avoided wherever possible. Soft rules are a preference, and may be traded off against visibility and balanced groups. If a conflict remains, it will be visible on the classroom page.</p>
         <div style={{ borderTop: '1px solid #e6e1d5', paddingTop: 16, marginTop: 18 }}><Link href={`/classes/${classId}/planner`} className="button primary" data-testid="link-back-to-classroom"><ArrowLeft size={14} /> Review classroom map</Link></div>
      </section>
    </div>
  </main>;
}

const queryClient = new QueryClient();

function PlannerApp() {
  const [classes, setClasses] = useState<ClassRecord[]>(() => readClasses());
  const [, setLocation] = useLocation();
  useEffect(() => {
    try { localStorage.setItem(CLASSES_KEY, JSON.stringify(classes)); } catch { /* Current session remains usable without storage. */ }
  }, [classes]);
  const createClass = () => {
    const id = makeId();
    setClasses(current => [...current, { id, state: emptyClass(), createdAt: Date.now() }]);
    setLocation(`/classes/${id}/setup`);
  };
  const findClass = (id: string) => classes.find(item => item.id === id);
  const updateClass = (id: string, next: PlannerState) => setClasses(current => current.map(item => item.id === id ? { ...item, state: next } : item));
  return <AppFrame><Switch>
    <Route path="/"><Home /></Route>
    <Route path="/classes"><ClassesPage classes={classes} createClass={createClass} /></Route>
    <Route path="/classes/:classId/setup">{params => {
      const item = findClass(params.classId);
      return item ? <Setup state={item.state} update={next => updateClass(item.id, next)} classId={item.id} /> : <main className="page"><div className="rule-empty">This class isn’t available on this device. <Link href="/classes" className="text-link">Return to your class list</Link></div></main>;
    }}</Route>
    <Route path="/classes/:classId/planner">{params => {
      const item = findClass(params.classId);
      return item ? <Classroom state={item.state} update={next => updateClass(item.id, next)} classId={item.id} /> : <main className="page"><div className="rule-empty">This class isn’t available on this device. <Link href="/classes" className="text-link">Return to your class list</Link></div></main>;
    }}</Route>
    <Route component={NotFound} />
  </Switch></AppFrame>;
}

function Router() {
  return <ErrorBoundary><PlannerApp /></ErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;
